# User-interface-design-and-testing-project---Jobclick-website
UI/UX project on Jobclick website.
Jobclick Website (Java| Selenium WebDriver| Junit| Axure RP)                                                                               
•	Developed a wireframe for jobclick website, including features of job search and online learning portal. 
•	Performed automation testing through Selenium web driver.
